/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package BorrowLogs;

import DatabaseConnection.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class BorrowLogs extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BorrowLogs.class.getName());

    /**
     * Creates new form BorrowLogs
     */
    public BorrowLogs() {
        initComponents();
        loadBorrowLogs();
    }
    private void loadBorrowLogs() {

        DefaultTableModel model =
                (DefaultTableModel)
                tblBorrowLogs.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT bl.log_id, " +
                "bl.customer_id, " +
                "c.name, " +
                "bl.book_id, " +
                "b.title, " +
                "bl.borrow_date, " +
                "bl.deadline, " +
                "bl.return_date, " +
                "bl.status " +
                "FROM borrow_logs bl " +
                "JOIN customers c " +
                "ON bl.customer_id = c.customer_id " +
                "JOIN books b " +
                "ON bl.book_id = b.book_id " +
                "ORDER BY bl.log_id DESC";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                String returnDate =
                        rs.getString("return_date");

                if (returnDate == null) {
                    returnDate = "-";
                }

                model.addRow(
                        new Object[]{
                                rs.getInt("log_id"),
                                rs.getString("customer_id"),
                                rs.getString("name"),
                                rs.getInt("book_id"),
                                rs.getString("title"),
                                rs.getDate("borrow_date"),
                                rs.getDate("deadline"),
                                returnDate,
                                rs.getString("status")
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading borrow logs: "
                    + e.getMessage()
            );
        }
    }
    private void txtSearchKeyReleased(
            java.awt.event.KeyEvent evt) {

        String search =
                txtSearch.getText().trim();

        DefaultTableModel model =
                (DefaultTableModel)
                tblBorrowLogs.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT bl.log_id, " +
                "bl.customer_id, " +
                "c.name, " +
                "bl.book_id, " +
                "b.title, " +
                "bl.borrow_date, " +
                "bl.deadline, " +
                "bl.return_date, " +
                "bl.status " +
                "FROM borrow_logs bl " +
                "JOIN customers c " +
                "ON bl.customer_id = c.customer_id " +
                "JOIN books b " +
                "ON bl.book_id = b.book_id " +
                "WHERE bl.customer_id LIKE ? " +
                "OR c.name LIKE ? " +
                "OR b.title LIKE ? " +
                "ORDER BY bl.log_id DESC";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);
            pst.setString(3, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                String returnDate =
                        rs.getString("return_date");

                if (returnDate == null) {
                    returnDate = "-";
                }

                model.addRow(
                        new Object[]{
                                rs.getInt("log_id"),
                                rs.getString("customer_id"),
                                rs.getString("name"),
                                rs.getInt("book_id"),
                                rs.getString("title"),
                                rs.getDate("borrow_date"),
                                rs.getDate("deadline"),
                                returnDate,
                                rs.getString("status")
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search Error: "
                    + e.getMessage()
            );
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBorrowLogs = new javax.swing.JTable();
        scrollBorrowLogs = new javax.swing.JScrollBar();
        btnClose = new javax.swing.JButton();
        btnDeleteLog = new javax.swing.JButton();
        btnUpdateLog = new javax.swing.JButton();
        btnReturn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(238, 226, 210));

        jPanel2.setBackground(new java.awt.Color(248, 242, 232));

        tblBorrowLogs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Log ID", "Customer ID", "Book", "Borrow Date", "Deadline", "Return Date", "Status"
            }
        ));
        jScrollPane1.setViewportView(tblBorrowLogs);

        scrollBorrowLogs.setBackground(new java.awt.Color(255, 255, 255));

        btnClose.setBackground(new java.awt.Color(139, 94, 52));
        btnClose.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("Close");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        btnDeleteLog.setBackground(new java.awt.Color(139, 94, 52));
        btnDeleteLog.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDeleteLog.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteLog.setText("Delete");
        btnDeleteLog.addActionListener(this::btnDeleteLogActionPerformed);

        btnUpdateLog.setBackground(new java.awt.Color(139, 94, 52));
        btnUpdateLog.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnUpdateLog.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateLog.setText("Update");
        btnUpdateLog.addActionListener(this::btnUpdateLogActionPerformed);

        btnReturn.setBackground(new java.awt.Color(139, 94, 52));
        btnReturn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnReturn.setForeground(new java.awt.Color(255, 255, 255));
        btnReturn.setText("Return");
        btnReturn.addActionListener(this::btnReturnActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdateLog, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDeleteLog, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 828, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(scrollBorrowLogs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(scrollBorrowLogs, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClose)
                    .addComponent(btnDeleteLog)
                    .addComponent(btnUpdateLog)
                    .addComponent(btnReturn))
                .addGap(15, 15, 15))
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(139, 94, 52));
        jLabel1.setText("Borrow Log");

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(139, 94, 52));
        jLabel2.setText("📋");

        txtSearch.addActionListener(this::txtSearchActionPerformed);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(139, 94, 52));
        jLabel3.setText("Search:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReturnActionPerformed
        int row =
                tblBorrowLogs.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a borrowing record."
            );

            return;
        }

        int logId =
                Integer.parseInt(
                        tblBorrowLogs
                                .getValueAt(row, 0)
                                .toString()
                );

        String status =
                tblBorrowLogs
                        .getValueAt(row, 6)
                        .toString();

        if (status.equals("Returned")) {

            JOptionPane.showMessageDialog(
                    this,
                    "This book has already been returned."
            );

            return;
        }

        Connection con = null;

        try {

            con =
                    DatabaseConnection.getConnection();

            con.setAutoCommit(false);

            int bookId =
                    Integer.parseInt(
                            tblBorrowLogs
                                    .getValueAt(row, 3)
                                    .toString()
                    );

            String logSql =
                    "UPDATE borrow_logs " +
                    "SET return_date = CURDATE(), " +
                    "status = 'Returned' " +
                    "WHERE log_id = ?";

            PreparedStatement logPst =
                    con.prepareStatement(logSql);

            logPst.setInt(1, logId);

            logPst.executeUpdate();

            logPst.close();

            String bookSql =
                    "UPDATE books " +
                    "SET status = 'Available' " +
                    "WHERE book_id = ?";

            PreparedStatement bookPst =
                    con.prepareStatement(bookSql);

            bookPst.setInt(1, bookId);

            bookPst.executeUpdate();

            bookPst.close();

            con.commit();

            JOptionPane.showMessageDialog(
                    this,
                    "Book returned successfully!"
            );

            loadBorrowLogs();

        } catch (Exception e) {

            try {

                if (con != null) {
                    con.rollback();
                }

            } catch (Exception ignored) {
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Return Error: "
                    + e.getMessage()
            );

        } finally {

            try {

                if (con != null) {
                    con.close();
                }

            } catch (Exception ignored) {
            }
        }
    }//GEN-LAST:event_btnReturnActionPerformed

    private void btnUpdateLogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateLogActionPerformed
        int row =
                tblBorrowLogs.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a borrowing record."
            );

            return;
        }

        int logId =
                Integer.parseInt(
                        tblBorrowLogs
                                .getValueAt(row, 0)
                                .toString()
                );

        String deadline =
                JOptionPane.showInputDialog(
                        this,
                        "Enter new deadline:",
                        tblBorrowLogs
                                .getValueAt(row, 6)
                                .toString()
                );

        if (deadline == null ||
                deadline.trim().isEmpty()) {
            return;
        }

        String sql =
                "UPDATE borrow_logs " +
                "SET deadline = ? " +
                "WHERE log_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setString(1, deadline);
            pst.setInt(2, logId);

            pst.executeUpdate();

            pst.close();
            con.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Borrow log updated successfully!"
            );

            loadBorrowLogs();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Update Log Error: "
                    + e.getMessage()
            );
        }
    }//GEN-LAST:event_btnUpdateLogActionPerformed

    private void btnDeleteLogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteLogActionPerformed
        int row = tblBorrowLogs.getSelectedRow();

    if (row == -1) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a borrowing record."
        );

        return;
    }

    int logId = Integer.parseInt(
            tblBorrowLogs
                    .getValueAt(row, 0)
                    .toString()
    );

    int bookId = Integer.parseInt(
            tblBorrowLogs
                    .getValueAt(row, 3)
                    .toString()
    );

    String status = tblBorrowLogs
            .getValueAt(row, 6)
            .toString();

    int choice = JOptionPane.showConfirmDialog(
            this,
            "Delete this borrow log?",
            "Delete Borrow Log",
            JOptionPane.YES_NO_OPTION
    );

    if (choice != JOptionPane.YES_OPTION) {
        return;
    }

    Connection con = null;

    try {

        con = DatabaseConnection.getConnection();

        con.setAutoCommit(false);

        String sql =
                "DELETE FROM borrow_logs " +
                "WHERE log_id = ?";

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, logId);

        pst.executeUpdate();

        pst.close();

        if (status.equals("Borrowed")) {

            String bookSql =
                    "UPDATE books " +
                    "SET status = 'Available' " +
                    "WHERE book_id = ?";

            PreparedStatement bookPst =
                    con.prepareStatement(bookSql);

            bookPst.setInt(1, bookId);

            bookPst.executeUpdate();

            bookPst.close();
        }

        con.commit();

        JOptionPane.showMessageDialog(
                this,
                "Borrow log deleted successfully!"
        );

        loadBorrowLogs();

    } catch (Exception e) {

        try {

            if (con != null) {
                con.rollback();
            }

        } catch (Exception ignored) {
        }

        JOptionPane.showMessageDialog(
                this,
                "Delete Log Error: "
                + e.getMessage()
        );

    } finally {

        try {

            if (con != null) {
                con.close();
            }

        } catch (Exception ignored) {
        }
    }
    }//GEN-LAST:event_btnDeleteLogActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BorrowLogs().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnDeleteLog;
    private javax.swing.JButton btnReturn;
    private javax.swing.JButton btnUpdateLog;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollBar scrollBorrowLogs;
    private javax.swing.JTable tblBorrowLogs;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
