package Main;

import DatabaseConnection.DatabaseConnection;
import java.sql.Connection;
import Login.Login;
public class Main {

    public static void main(String[] args) {

        Connection con =
                DatabaseConnection.getConnection();

        if (con != null) {

            System.out.println(
                    "CONNECTION SUCCESSFUL!"
            );

        } else {

            System.out.println(
                    "CONNECTION FAILED!"
            );
        }
        java.awt.EventQueue.invokeLater(() -> {

            new Login().setVisible(true);

        });
    }
}