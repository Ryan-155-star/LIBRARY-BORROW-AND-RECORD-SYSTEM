package CustomersBooks;

public class CustomersBooks {

    private String customerId;
    private int bookId;
    private String borrowDate;
    private String deadline;
    private String returnDate;
    private String status;

    public CustomersBooks(
            String customerId,
            int bookId,
            String borrowDate,
            String deadline
    ) {
        this.customerId = customerId;
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.deadline = deadline;
        this.returnDate = "";
        this.status = "Borrowed";
    }

    public String getCustomerId() {
        return customerId;
    }

    public int getBookId() {
        return bookId;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public String getDeadline() {
        return deadline;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void returnBook(String returnDate) {
        this.returnDate = returnDate;
        this.status = "Returned";
    }
}