/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ViewBooks;

import DatabaseConnection.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class ViewBooks extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ViewBooks.class.getName());

    private String userRole;
    public ViewBooks(String userRole) {
        initComponents();
        this.userRole = userRole;

        loadCategories();
        loadBooks();
    }
    private boolean isAdmin() {
        return userRole != null
                && userRole.equalsIgnoreCase("Admin");
    }
    private void adminOnly() {
        JOptionPane.showMessageDialog(
                this,
                "Admin only. You do not have permission to access this function."
        );
    }
     private void loadCategories() {

        cmbCategory.removeAllItems();
        cmbCategory.addItem("All");

        String sql =
                "SELECT category_name " +
                "FROM categories " +
                "ORDER BY category_name";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            if (con == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );
                return;
            }

            PreparedStatement pst =
                    con.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {
                cmbCategory.addItem(
                        rs.getString("category_name")
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database Error: " + e.getMessage()
            );
        }
    }
     private void loadBooks() {

        DefaultTableModel model =
                (DefaultTableModel) tblBooks.getModel();

        model.setRowCount(0);

        String search =
                txtSearch.getText().trim();

        String category =
                cmbCategory.getSelectedItem() == null
                ? "All"
                : cmbCategory.getSelectedItem().toString();

        String sql =
                "SELECT b.book_id, " +
                "b.title, " +
                "b.author, " +
                "c.category_name, " +
                "b.quantity, " +
                "b.available_quantity, " +
                "b.status " +
                "FROM books b " +
                "JOIN categories c " +
                "ON b.category_id = c.category_id " +
                "WHERE (b.title LIKE ? " +
                "OR b.author LIKE ? " +
                "OR c.category_name LIKE ?) ";

        if (!category.equals("All")) {
            sql += "AND c.category_name = ? ";
        }

        sql += "ORDER BY b.book_id";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            if (con == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );
                return;
            }

            PreparedStatement pst =
                    con.prepareStatement(sql);

            String searchValue =
                    "%" + search + "%";

            pst.setString(1, searchValue);
            pst.setString(2, searchValue);
            pst.setString(3, searchValue);

            if (!category.equals("All")) {
                pst.setString(4, category);
            }

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                            rs.getInt("book_id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getString("category_name"),
                            rs.getInt("quantity"),
                            rs.getInt("available_quantity"),
                            rs.getString("status")
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database Error: " + e.getMessage()
            );
        }
    }
    private void txtSearchKeyReleased(
            java.awt.event.KeyEvent evt) {

        String search =
                txtSearch.getText().trim();

        DefaultTableModel model =
                (DefaultTableModel)
                tblBooks.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT book_id, title, author, genre, status " +
                "FROM books " +
                "WHERE title LIKE ? " +
                "OR author LIKE ? " +
                "OR genre LIKE ? " +
                "ORDER BY book_id";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);
            pst.setString(3, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                                rs.getInt("book_id"),
                                rs.getString("title"),
                                rs.getString("author"),
                                rs.getString("genre"),
                                rs.getString("status")
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search Error: "
                    + e.getMessage()
            );
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBooks = new javax.swing.JTable();
        btnClose = new javax.swing.JButton();
        btnDeleteBook = new javax.swing.JButton();
        btnUpdateBook = new javax.swing.JButton();
        btnAddBook = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(96, 59, 42));

        jPanel2.setBackground(new java.awt.Color(248, 242, 232));

        tblBooks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Book Title", "Author", "Genre", "Quantity", "Available", "Status"
            }
        ));
        jScrollPane1.setViewportView(tblBooks);

        btnClose.setBackground(new java.awt.Color(204, 204, 204));
        btnClose.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        btnDeleteBook.setBackground(new java.awt.Color(204, 0, 0));
        btnDeleteBook.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDeleteBook.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteBook.setText("DELETE");
        btnDeleteBook.addActionListener(this::btnDeleteBookActionPerformed);

        btnUpdateBook.setBackground(new java.awt.Color(0, 153, 255));
        btnUpdateBook.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnUpdateBook.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateBook.setText("UPDATE");
        btnUpdateBook.addActionListener(this::btnUpdateBookActionPerformed);

        btnAddBook.setBackground(new java.awt.Color(139, 94, 52));
        btnAddBook.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnAddBook.setForeground(new java.awt.Color(255, 255, 255));
        btnAddBook.setText("ADD");
        btnAddBook.addActionListener(this::btnAddBookActionPerformed);

        btnRefresh.setBackground(new java.awt.Color(102, 204, 0));
        btnRefresh.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("REFRESH");
        btnRefresh.addActionListener(this::btnRefreshActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 985, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAddBook, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnUpdateBook, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDeleteBook, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClose)
                    .addComponent(btnDeleteBook)
                    .addComponent(btnUpdateBook)
                    .addComponent(btnAddBook)
                    .addComponent(btnRefresh))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jLabel1.setBackground(new java.awt.Color(139, 94, 52));
        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("📖");

        jLabel2.setFont(new java.awt.Font("SimSun-ExtB", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Books");

        txtSearch.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtSearch.addActionListener(this::txtSearchActionPerformed);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Search:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Categories:");

        cmbCategory.addActionListener(this::cmbCategoryActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(278, 278, 278)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel4)
                .addGap(31, 31, 31)
                .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddBookActionPerformed
        if (!isAdmin()) {
            adminOnly();
            return;
        }

        new Addbook(userRole).setVisible(true);
    }//GEN-LAST:event_btnAddBookActionPerformed

    private void btnUpdateBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateBookActionPerformed
         if (!isAdmin()) {
            adminOnly();
            return;
        }

        int row =
                tblBooks.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a book."
            );

            return;
        }

        int bookId =
                Integer.parseInt(
                        tblBooks
                                .getValueAt(row, 0)
                                .toString()
                );

        String oldTitle =
                tblBooks
                        .getValueAt(row, 1)
                        .toString();

        String oldAuthor =
                tblBooks
                        .getValueAt(row, 2)
                        .toString();

        String oldCategory =
                tblBooks
                        .getValueAt(row, 3)
                        .toString();

        int oldQuantity =
                Integer.parseInt(
                        tblBooks
                                .getValueAt(row, 4)
                                .toString()
                );

        String newTitle =
                JOptionPane.showInputDialog(
                        this,
                        "Enter book title:",
                        oldTitle
                );

        if (newTitle == null) {
            return;
        }

        newTitle = newTitle.trim();

        if (newTitle.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Book title cannot be empty."
            );
            return;
        }

        String newAuthor =
                JOptionPane.showInputDialog(
                        this,
                        "Enter author:",
                        oldAuthor
                );

        if (newAuthor == null) {
            return;
        }

        newAuthor = newAuthor.trim();

        if (newAuthor.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Author cannot be empty."
            );
            return;
        }

        String quantityInput =
                JOptionPane.showInputDialog(
                        this,
                        "Enter quantity:",
                        oldQuantity
                );

        if (quantityInput == null) {
            return;
        }

        int newQuantity;

        try {

            newQuantity =
                    Integer.parseInt(
                            quantityInput.trim()
                    );

            if (newQuantity <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Quantity must be greater than 0."
                );

                return;
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Quantity must be a number."
            );

            return;
        }

        String categoryInput =
                JOptionPane.showInputDialog(
                        this,
                        "Enter category:",
                        oldCategory
                );

        if (categoryInput == null) {
            return;
        }

        categoryInput =
                categoryInput.trim();

        if (categoryInput.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Category cannot be empty."
            );

            return;
        }

        Connection con = null;

        try {

            con =
                    DatabaseConnection.getConnection();

            if (con == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );

                return;
            }

            con.setAutoCommit(false);

            String categorySql =
                    "SELECT category_id " +
                    "FROM categories " +
                    "WHERE category_name = ?";

            PreparedStatement categoryPst =
                    con.prepareStatement(categorySql);

            categoryPst.setString(
                    1,
                    categoryInput
            );

            ResultSet categoryRs =
                    categoryPst.executeQuery();

            if (!categoryRs.next()) {

                categoryRs.close();
                categoryPst.close();
                con.rollback();

                JOptionPane.showMessageDialog(
                        this,
                        "Category not found."
                );

                return;
            }

            int categoryId =
                    categoryRs.getInt("category_id");

            categoryRs.close();
            categoryPst.close();

            String getBookSql =
                    "SELECT quantity, available_quantity " +
                    "FROM books " +
                    "WHERE book_id = ?";

            PreparedStatement getBookPst =
                    con.prepareStatement(getBookSql);

            getBookPst.setInt(
                    1,
                    bookId
            );

            ResultSet bookRs =
                    getBookPst.executeQuery();

            if (!bookRs.next()) {

                bookRs.close();
                getBookPst.close();
                con.rollback();

                JOptionPane.showMessageDialog(
                        this,
                        "Book not found."
                );

                return;
            }

            int oldDbQuantity =
                    bookRs.getInt("quantity");

            int availableQuantity =
                    bookRs.getInt("available_quantity");

            bookRs.close();
            getBookPst.close();

            int borrowedQuantity =
                    oldDbQuantity - availableQuantity;

            if (newQuantity < borrowedQuantity) {

                con.rollback();

                JOptionPane.showMessageDialog(
                        this,
                        "Quantity cannot be lower than the number of currently borrowed copies."
                );

                return;
            }

            int newAvailableQuantity =
                    newQuantity - borrowedQuantity;

            String status;

            if (newAvailableQuantity == 0) {
                status = "Out of Stock";
            } else {
                status = "Available";
            }

            String updateSql =
                    "UPDATE books " +
                    "SET title = ?, " +
                    "author = ?, " +
                    "category_id = ?, " +
                    "quantity = ?, " +
                    "available_quantity = ?, " +
                    "status = ? " +
                    "WHERE book_id = ?";

            PreparedStatement updatePst =
                    con.prepareStatement(updateSql);

            updatePst.setString(1, newTitle);
            updatePst.setString(2, newAuthor);
            updatePst.setInt(3, categoryId);
            updatePst.setInt(4, newQuantity);
            updatePst.setInt(5, newAvailableQuantity);
            updatePst.setString(6, status);
            updatePst.setInt(7, bookId);

            updatePst.executeUpdate();

            updatePst.close();

            con.commit();

            JOptionPane.showMessageDialog(
                    this,
                    "Book updated successfully."
            );

            loadBooks();

        } catch (Exception e) {

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Database Error: " + e.getMessage()
            );

        } finally {

            try {

                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }

            } catch (Exception e) {
            }
        }
        
        
    }//GEN-LAST:event_btnUpdateBookActionPerformed

    private void btnDeleteBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteBookActionPerformed
        if (!isAdmin()) {
            adminOnly();
            return;
        }

        int row =
                tblBooks.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a book."
            );

            return;
        }

        int bookId =
                Integer.parseInt(
                        tblBooks
                                .getValueAt(row, 0)
                                .toString()
                );

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete this book?",
                        "Delete Book",
                        JOptionPane.YES_NO_OPTION
                );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "DELETE FROM books WHERE book_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            if (con == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );

                return;
            }

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setInt(1, bookId);

            pst.executeUpdate();

            pst.close();
            con.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Book deleted successfully."
            );

            loadBooks();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot delete this book. It may have existing borrow records."
            );
        }
    }//GEN-LAST:event_btnDeleteBookActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        loadBooks();
    }//GEN-LAST:event_txtSearchActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
         if (cmbCategory.getSelectedItem() != null) {
            loadBooks();
        }
    }

    public void refreshBooks() {
        loadBooks();
    
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        txtSearch.setText("");

        if (cmbCategory.getItemCount() > 0) {
            cmbCategory.setSelectedIndex(0);
        }

        loadBooks();
    }//GEN-LAST:event_btnRefreshActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ViewBooks("Admin").setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddBook;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnDeleteBook;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnUpdateBook;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblBooks;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
