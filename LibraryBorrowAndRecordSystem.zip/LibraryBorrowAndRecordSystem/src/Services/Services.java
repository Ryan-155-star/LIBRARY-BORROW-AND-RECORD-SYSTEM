package Services;

import DatabaseConnection.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Services {

    public static boolean login(
            String username,
            String password
    ) {

        String sql =
                "SELECT * FROM users " +
                "WHERE username = ? AND password = ?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setString(1, username);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

            return rs.next();

        } catch (Exception e) {

            System.out.println(
                    "Login Error: "
                    + e.getMessage()
            );

            return false;
        }
    }

    public static int getTotalBooks() {

        return getCount(
                "SELECT COUNT(*) FROM books"
        );
    }

    public static int getTotalCustomers() {

        return getCount(
                "SELECT COUNT(*) FROM customers"
        );
    }

    public static int getBorrowedBooks() {

        return getCount(
                "SELECT COUNT(*) FROM books " +
                "WHERE status = 'Borrowed'"
        );
    }

    public static int getTotalLogs() {

        return getCount(
                "SELECT COUNT(*) FROM borrow_logs"
        );
    }

    private static int getCount(String sql) {

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql);

                ResultSet rs =
                        pst.executeQuery()
        ) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {

            System.out.println(
                    "Count Error: "
                    + e.getMessage()
            );
        }

        return 0;
    }
}