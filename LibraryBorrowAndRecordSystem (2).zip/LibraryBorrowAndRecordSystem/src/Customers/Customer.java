package Customers;

public class Customer {

    private int customerId;
    private String lastName;
    private String firstName;
    private String address;
    private String email;
    private String contact;
    private String status;

    public Customer(
            int customerId,
            String lastName,
            String firstName,
            String address,
            String email,
            String contact,
            String status) {

        this.customerId = customerId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.address = address;
        this.email = email;
        this.contact = contact;
        this.status = status;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getContact() {
        return contact;
    }

    public String getStatus() {
        return status;
    }
}