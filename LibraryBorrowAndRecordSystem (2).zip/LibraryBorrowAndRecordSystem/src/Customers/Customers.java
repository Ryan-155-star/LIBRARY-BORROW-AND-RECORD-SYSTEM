/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Customers;

import DatabaseConnection.DatabaseConnection;
import Register.Register;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Customers extends javax.swing.JFrame {
    
    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Customers.class.getName());

    private String userRole;
    
    public Customers(String userRole) {
        initComponents();

        this.userRole = userRole;

        loadCustomers();
    }
    private boolean isAdmin() {

        return userRole.equalsIgnoreCase("Admin");
    }
    private void adminOnly() {

        JOptionPane.showMessageDialog(
                this,
                "Admin only. You do not have permission to access this function."
        );
    }
    private void loadCustomers() {

        DefaultTableModel model =
                (DefaultTableModel)
                tblCustomers.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT customer_id, " +
                "customer_lastname, " +
                "customer_firstname, " +
                "customer_address, " +
                "customer_email, " +
                "customer_contact " +
                "FROM customers " +
                "ORDER BY customer_id";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                                String.format(
                                        "C%03d",
                                        rs.getInt(
                                                "customer_id"
                                        )
                                ),
                                rs.getString(
                                        "customer_lastname"
                                ),
                                rs.getString(
                                        "customer_firstname"
                                ),
                                rs.getString(
                                        "customer_address"
                                ),
                                rs.getString(
                                        "customer_email"
                                ),
                                rs.getString(
                                        "customer_contact"
                                )
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading customers: "
                    + e.getMessage()
            );
        }
    }
    private void txtSearchKeyReleased(
            java.awt.event.KeyEvent evt) {

        String search =
                txtSearch.getText().trim();

        DefaultTableModel model =
                (DefaultTableModel)
                tblCustomers.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT customer_id, " +
                "customer_lastname, " +
                "customer_firstname, " +
                "customer_address, " +
                "customer_email, " +
                "customer_contact " +
                "FROM customers " +
                "WHERE CAST(customer_id AS CHAR) LIKE ? " +
                "OR customer_lastname LIKE ? " +
                "OR customer_firstname LIKE ? " +
                "OR customer_address LIKE ? " +
                "OR customer_email LIKE ? " +
                "OR customer_contact LIKE ? " +
                "ORDER BY customer_id";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);
            pst.setString(3, value);
            pst.setString(4, value);
            pst.setString(5, value);
            pst.setString(6, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                                String.format(
                                        "C%03d",
                                        rs.getInt(
                                                "customer_id"
                                        )
                                ),
                                rs.getString(
                                        "customer_lastname"
                                ),
                                rs.getString(
                                        "customer_firstname"
                                ),
                                rs.getString(
                                        "customer_address"
                                ),
                                rs.getString(
                                        "customer_email"
                                ),
                                rs.getString(
                                        "customer_contact"
                                )
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search Error: "
                    + e.getMessage()
            );
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCustomers = new javax.swing.JTable();
        btnDeleteCustomer = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        btnUpdateCustomer = new javax.swing.JButton();
        btnRegister = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(96, 59, 42));

        jPanel2.setBackground(new java.awt.Color(248, 242, 232));

        tblCustomers.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        tblCustomers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Customer ID", "Last Name", "First Name", "Address", "Email", "Contact"
            }
        ));
        jScrollPane1.setViewportView(tblCustomers);

        btnDeleteCustomer.setBackground(new java.awt.Color(204, 0, 0));
        btnDeleteCustomer.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDeleteCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteCustomer.setText("DELETE");
        btnDeleteCustomer.addActionListener(this::btnDeleteCustomerActionPerformed);

        btnClose.setBackground(new java.awt.Color(204, 204, 204));
        btnClose.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        btnUpdateCustomer.setBackground(new java.awt.Color(0, 153, 255));
        btnUpdateCustomer.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnUpdateCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateCustomer.setText("UPDATE");
        btnUpdateCustomer.addActionListener(this::btnUpdateCustomerActionPerformed);

        btnRegister.setBackground(new java.awt.Color(139, 94, 52));
        btnRegister.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("REGISTER");
        btnRegister.addActionListener(this::btnRegisterActionPerformed);

        btnRefresh.setBackground(new java.awt.Color(102, 204, 0));
        btnRefresh.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("REFRESH");
        btnRefresh.addActionListener(this::btnRefreshActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRegister)
                .addGap(22, 22, 22)
                .addComponent(btnUpdateCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDeleteCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRefresh)
                .addGap(16, 16, 16)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 868, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeleteCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUpdateCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRegister, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("👥");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Customers");

        txtSearch.addActionListener(this::txtSearchActionPerformed);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Search:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 435, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(133, 133, 133))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        new Register().setVisible(true);
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void btnUpdateCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateCustomerActionPerformed
                int row =
                tblCustomers.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer."
            );

            return;
        }

        int customerId =
                Integer.parseInt(
                        tblCustomers
                                .getValueAt(row, 0)
                                .toString()
                                .substring(1)
                );

        String lastName =
                JOptionPane.showInputDialog(
                        this,
                        "Enter lastname:",
                        tblCustomers
                                .getValueAt(row, 1)
                                .toString()
                );

        if (lastName == null ||
                lastName.trim().isEmpty()) {
            return;
        }

        String firstName =
                JOptionPane.showInputDialog(
                        this,
                        "Enter firstname:",
                        tblCustomers
                                .getValueAt(row, 2)
                                .toString()
                );

        if (firstName == null ||
                firstName.trim().isEmpty()) {
            return;
        }

        String address =
                JOptionPane.showInputDialog(
                        this,
                        "Enter address:",
                        tblCustomers
                                .getValueAt(row, 3)
                                .toString()
                );

        if (address == null ||
                address.trim().isEmpty()) {
            return;
        }

        String email =
                JOptionPane.showInputDialog(
                        this,
                        "Enter email:",
                        tblCustomers
                                .getValueAt(row, 4)
                                .toString()
                );

        if (email == null ||
                email.trim().isEmpty()) {
            return;
        }

        String contact =
                JOptionPane.showInputDialog(
                        this,
                        "Enter contact:",
                        tblCustomers
                                .getValueAt(row, 5)
                                .toString()
                );

        if (contact == null ||
                contact.trim().isEmpty()) {
            return;
        }

        String sql =
                "UPDATE customers SET " +
                "customer_lastname = ?, " +
                "customer_firstname = ?, " +
                "customer_address = ?, " +
                "customer_email = ?, " +
                "customer_contact = ? " +
                "WHERE customer_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setString(1, lastName);
            pst.setString(2, firstName);
            pst.setString(3, address);
            pst.setString(4, email);
            pst.setString(5, contact);
            pst.setInt(6, customerId);

            pst.executeUpdate();

            pst.close();
            con.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Customer updated successfully!"
            );

            loadCustomers();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Update Error: "
                    + e.getMessage()
            );
        }
    }//GEN-LAST:event_btnUpdateCustomerActionPerformed

    private void btnDeleteCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteCustomerActionPerformed
                if (!isAdmin()) {

            adminOnly();
            return;
        }

        int row =
                tblCustomers.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer."
            );

            return;
        }

        int customerId =
                Integer.parseInt(
                        tblCustomers
                                .getValueAt(row, 0)
                                .toString()
                                .substring(1)
                );

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete this customer?",
                        "Delete Customer",
                        JOptionPane.YES_NO_OPTION
                );

        if (choice !=
                JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "DELETE FROM customers " +
                "WHERE customer_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setInt(1, customerId);

            pst.executeUpdate();

            pst.close();
            con.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Customer deleted successfully!"
            );

            loadCustomers();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Delete Error: "
                    + e.getMessage()
            );
        }
    }//GEN-LAST:event_btnDeleteCustomerActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        String search =
                txtSearch.getText().trim();

        DefaultTableModel model =
                (DefaultTableModel)
                tblCustomers.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT customer_id, " +
                "customer_lastname, " +
                "customer_firstname, " +
                "customer_address, " +
                "customer_email, " +
                "customer_contact " +
                "FROM customers " +
                "WHERE CAST(customer_id AS CHAR) LIKE ? " +
                "OR customer_lastname LIKE ? " +
                "OR customer_firstname LIKE ? " +
                "OR customer_address LIKE ? " +
                "OR customer_email LIKE ? " +
                "OR customer_contact LIKE ? " +
                "ORDER BY customer_id";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);
            pst.setString(3, value);
            pst.setString(4, value);
            pst.setString(5, value);
            pst.setString(6, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                                String.format(
                                        "C%03d",
                                        rs.getInt(
                                                "customer_id"
                                        )
                                ),
                                rs.getString(
                                        "customer_lastname"
                                ),
                                rs.getString(
                                        "customer_firstname"
                                ),
                                rs.getString(
                                        "customer_address"
                                ),
                                rs.getString(
                                        "customer_email"
                                ),
                                rs.getString(
                                        "customer_contact"
                                )
                        }
                );
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search Error: "
                    + e.getMessage()
            );
        }
    }//GEN-LAST:event_txtSearchActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        loadCustomers();
    }//GEN-LAST:event_btnRefreshActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Customers("Admin").setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnDeleteCustomer;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnUpdateCustomer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCustomers;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
