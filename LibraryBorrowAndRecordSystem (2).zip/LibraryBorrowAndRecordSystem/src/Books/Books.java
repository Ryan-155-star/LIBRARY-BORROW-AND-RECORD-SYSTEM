package Books;

public class Books {

    private int bookId;
    private String title;
    private String author;
    private int categoryId;
    private int quantity;
    private int availableQuantity;
    private String status;

    public Books(
            int bookId,
            String title,
            String author,
            int categoryId,
            int quantity,
            int availableQuantity,
            String status) {

        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.categoryId = categoryId;
        this.quantity = quantity;
        this.availableQuantity = availableQuantity;
        this.status = status;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }

    public String getStatus() {
        return status;
    }
}