package Books;

public class Books {

    private int bookId;
    private String title;
    private String author;
    private String genre;
    private int aisle;
    private boolean available;

    public Books(int bookId, String title, String author, String genre, int aisle) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.aisle = aisle;
        this.available = true;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public int getAisle() {
        return aisle;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}