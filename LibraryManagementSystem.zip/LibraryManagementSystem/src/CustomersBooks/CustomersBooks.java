package CustomersBooks;

public class CustomersBooks {

    private int customerId;
    private int bookId;
    private String customerName;
    private String bookTitle;
    private String borrowDate;
    private String deadline;
    private String returnDate;

    public CustomersBooks(int customerId, int bookId,
                          String customerName, String bookTitle,
                          String borrowDate, String deadline) {

        this.customerId = customerId;
        this.bookId = bookId;
        this.customerName = customerName;
        this.bookTitle = bookTitle;
        this.borrowDate = borrowDate;
        this.deadline = deadline;
        this.returnDate = "";
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getBookId() {
        return bookId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public String getDeadline() {
        return deadline;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }
}