package Services;

import Books.Books;
import Customers.Customers;
import CustomersBooks.CustomersBooks;

import java.util.ArrayList;

public class Services {

    public static ArrayList<Books> books = new ArrayList<>();
    public static ArrayList<Customers> customers = new ArrayList<>();
    public static ArrayList<CustomersBooks> borrowLog = new ArrayList<>();

    public static void loadBooks() {

        if (!books.isEmpty()) {
            return;
        }

        books.add(new Books(
                1,
                "Java Programming",
                "James Smith",
                "Programming",
                1
        ));

        books.add(new Books(
                2,
                "Introduction to IT",
                "John Cruz",
                "Information Technology",
                1
        ));

        books.add(new Books(
                3,
                "Law Basics",
                "Robert Santos",
                "Law",
                2
        ));

        books.add(new Books(
                4,
                "Medical Science",
                "Anna Garcia",
                "Medicine",
                3
        ));

        books.add(new Books(
                5,
                "The Lost World",
                "Arthur Doyle",
                "Fiction",
                4
        ));

        books.add(new Books(
                6,
                "Database Fundamentals",
                "Mark Lee",
                "Programming",
                2
        ));

        books.add(new Books(
                7,
                "Computer Networks",
                "David Brown",
                "Information Technology",
                3
        ));

        books.add(new Books(
                8,
                "World History",
                "Michael Jones",
                "History",
                4
        ));
    }

    public static Books findBook(int id) {

        for (Books book : books) {

            if (book.getBookId() == id) {
                return book;
            }
        }

        return null;
    }

    public static Customers findCustomer(int id) {

        for (Customers customer : customers) {

            if (customer.getCustomerId() == id) {
                return customer;
            }
        }

        return null;
    }

    public static boolean addCustomer(
            int id,
            String name,
            String contact,
            String address) {

        if (findCustomer(id) != null) {
            return false;
        }

        customers.add(
                new Customers(
                        id,
                        name,
                        contact,
                        address
                )
        );

        return true;
    }

    public static boolean borrowBook(
            int customerId,
            int bookId,
            String customerName,
            String bookTitle,
            String borrowDate,
            String deadline) {

        Books book = findBook(bookId);

        if (book == null) {
            return false;
        }

        if (!book.isAvailable()) {
            return false;
        }

        book.setAvailable(false);

        CustomersBooks record =
                new CustomersBooks(
                        customerId,
                        bookId,
                        customerName,
                        bookTitle,
                        borrowDate,
                        deadline
                );

        borrowLog.add(record);

        return true;
    }

    public static boolean returnBook(
            int bookId,
            String returnDate) {

        Books book = findBook(bookId);

        if (book == null) {
            return false;
        }

        if (book.isAvailable()) {
            return false;
        }

        for (CustomersBooks record : borrowLog) {

            if (record.getBookId() == bookId
                    && record.getReturnDate().equals("")) {

                record.setReturnDate(returnDate);
                book.setAvailable(true);

                return true;
            }
        }

        return false;
    }

    public static ArrayList<CustomersBooks> searchCustomer(
            String name) {

        ArrayList<CustomersBooks> result =
                new ArrayList<>();

        for (CustomersBooks record : borrowLog) {

            if (record.getCustomerName()
                    .toLowerCase()
                    .contains(name.toLowerCase())) {

                result.add(record);
            }
        }

        return result;
    }
}
