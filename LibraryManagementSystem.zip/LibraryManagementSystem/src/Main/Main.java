package Main;

import LogIn.LogIn;
import Services.Services;

public class Main {

    public static void main(String[] args) {

        Services.loadBooks();

        LogIn login = new LogIn();

        login.setVisible(true);
    }
}